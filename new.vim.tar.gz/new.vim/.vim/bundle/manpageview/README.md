This is a mirror of manpageview (v25q, Feb 21, 2015), a vim plugin for easy viewing of man pages in vim under Unix systems.
The plugin has been "withdrawn" from vim.org so this serves as a repository that can be used with Vundle.

The original plugin uses the VimBall format, but I have changed this to a flat layout because VimBall sucks.

Original website: http://www.drchip.org/astronaut/vim/index.html#MANPAGEVIEW

# Copyright

    Author: Charles E. Campbell, Jr.  <NdrchipO@ScampbellPfamily.AbizM>
            (remove NOSPAM from Campbell's email first)
    Copyright: (c) 2004-2011 by Charles E. Campbell, Jr.
              The VIM LICENSE applies to ManPageView.vim and ManPageView.txt
              (see copyright) except use 'ManPageView' instead of 'Vim'
              no warranty, express or implied.  use at-your-own-risk.
